"""ydhlw URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from . import views,get,post

urlpatterns = [
    path('ping/', views.ping),
    path('index/', views.index),
    path('search_get/', get.search_get),
    path('search_get_any/', get.search_get_any),
    path('search_get_any_num/', get.search_get_any_num),
    path('load/', get.load),
    path('all/', get.get_all),
    path('no/', get.get_no),
    path('yes/', get.get_yes),
    path('del/', get.get_del),
    path('root/', get.get_root),
    path('get_report/', get.get_report),
    path('search_post/', post.search_post),
    path('sign/', post.sign),
    path('title/', post.change_title),
    path('record/', post.post_record),
    path('me/', post.post_me),
    path('pd/', post.post_pd),
    path('post_report/', post.post_report),
]
