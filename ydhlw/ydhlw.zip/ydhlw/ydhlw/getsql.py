import pymysql


def pyconn():
    conn = pymysql.Connection(
        host='localhost',
        port=3306,
        user='root',
        password='3261099Zzh@',
        charset='utf8',
        db='mysql',
    )
    return conn


def get_data(table_name, point):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select = f'select * from {table_name} where user_num="{point}"'
    data_count = cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
    data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    cursor.close()
    conn.close()
    return data_count, data, point


def get_data_any(table_name, data1, data2):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select = f'select * from {table_name} where name like "%{data1}%" and num like "%{data2}%"'
    data_count = cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
    data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    cursor.close()
    conn.close()
    return data_count, data, [data1, data2]


def get_data_any_num(table_name, data1, data2, num1, num2):
    conn = pyconn()
    num1, num2 = int(num1), int(num2)
    cursor = conn.cursor()
    sql_select = f'select * from {table_name} where name like "%{data1}%" and num like "%{data2}%"'
    data_count = cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
    start_sql = (num1 - 1) * num2 + 1
    end_sql = min(data_count, num1 * num2)
    data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    data = data[start_sql:end_sql + 1]
    cursor.close()
    conn.close()
    return data_count, data, [data1, data2]


# 登录
def get_data_load(table_name, point):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select = f'select * from {table_name} where user_num="{point}"'
    data_count = cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
    data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    cursor.close()
    conn.close()
    return data_count, data, point


def get_data_all(table_name1, table_name2, point):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select = f'select * from {table_name1} left join {table_name2} on {table_name1}.user_num = {table_name2}.user_num where {table_name1}.user_num={point} and {table_name2}.user_num={point}'
    data_count = cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
    data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    cursor.close()
    conn.close()
    return data_count, data, point


def get_list(table_name1, table_name2, time, col, cla):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select1 = f'select user_num from {table_name1} where college like "%{col}%" and class like "%{cla}%"'
    cursor.execute(sql_select1)  # execute返回查询到的数据量，类型是int
    data1 = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行

    sql_select2 = f'select user_num from {table_name2} where time like "%{time}%"'
    cursor.execute(sql_select2)  # execute返回查询到的数据量，类型是int
    data2 = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    xt = []
    xp = []
    for i in data1:
        if i not in data2:
            xt.append(i)
    for i in xt:
        j = i[0]
        sql_select = f'select * from {table_name1} where user_num="{j}"'
        cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
        data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
        xp.append(data)
    cursor.close()
    conn.close()
    xp.sort()
    return xp, data2


def get_yes(table_name1, table_name2, time, num, title):
    conn = pyconn()
    cursor = conn.cursor()
    sql_select1 = f'select user_num from {table_name1} where user_num like "%{num}%"'
    cursor.execute(sql_select1)  # execute返回查询到的数据量，类型是int
    data1 = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行

    sql_select2 = f'select user_num from {table_name2} where time like "%{time}%"  and title like "%{title}%"'
    cursor.execute(sql_select2)  # execute返回查询到的数据量，类型是int
    data2 = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
    xt = []
    xp = []
    for i in data1:
        if i in data2:
            xt.append(i)
    for i in xt:
        j = i[0]
        sql_select = f'select * from {table_name1} left join {table_name2} on {table_name1}.user_num = {table_name2}.user_num where {table_name1}.user_num="{j}" and {table_name2}.time like "%{time}%"'
        cursor.execute(sql_select)  # execute返回查询到的数据量，类型是int
        data = cursor.fetchall()  # fetchall返回execute查询语句的数据，类型是元组，不包括字段行
        xp.append(data)
    cursor.close()
    conn.close()
    xp.sort()
    return xp, data2


def get_del(table_name1, table_name2, num):
    try:
        conn = pyconn()
        cursor = conn.cursor()
        sqlx = f'delete from {table_name1} where user_num="{num}"'
        sqly = f'delete from {table_name2} where user_num="{num}"'
        cursor.execute(sqlx)
        cursor.execute(sqly)
        conn.commit()
        conn.close()
        return True
    except:
        return False


def post_data(table_name, data1, data2):
    conn = pyconn()
    cursor = conn.cursor()
    data = {
        'name': str(data1),
        'num': str(data2),
    }
    table = table_name
    keys = ', '.join(data.keys())
    values = ', '.join(['%s'] * len(data))
    sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
    cursor.execute(sql, tuple(data.values()))
    conn.commit()
    cursor.close()
    conn.close()
    return True


def post_sign(table_name, num, pd, name, classx, tel, col):
    try:
        conn = pyconn()
        cursor = conn.cursor()
        data = {
            'user_num': str(num),
            'password': str(pd),
            'name': str(name),
            'class': str(classx),
            'telephone': str(tel),
            'college': str(col),
            'title': str('0')
        }
        table = table_name
        keys = ', '.join(data.keys())
        values = ', '.join(['%s'] * len(data))
        sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
        cursor.execute(sql, tuple(data.values()))
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except:
        return False


def post_title(table_name, num, title):
    conn=pyconn()
    cursor = conn.cursor()
    sql_title = f"UPDATE {table_name} SET title = {title} WHERE user_num = '{num}'"
    try:
        cursor.execute(sql_title)  # execute返回查询到的数据量，类型是int
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except:
        conn.rollback()
        cursor.close()
        conn.close()
        return False


def post_data(table_name, num, title, now):
    conn=pyconn()
    cursor = conn.cursor()
    data = {
        'user_num': str(num),
        'time': str(now),
        'title': str(title)
    }
    table = table_name
    keys = ', '.join(data.keys())
    values = ', '.join(['%s'] * len(data))
    sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
    cursor.execute(sql, tuple(data.values()))
    conn.commit()
    cursor.close()
    conn.close()
    return True


def post_record(table_name, num, title, now):
    conn=pyconn()
    cursor = conn.cursor()
    data = {
        'user_num': str(num),
        'time': str(now),
        'title': str(title)
    }
    table = table_name
    keys = ', '.join(data.keys())
    values = ', '.join(['%s'] * len(data))
    sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
    cursor.execute(sql, tuple(data.values()))
    conn.commit()
    cursor.close()
    conn.close()
    return True


def post_me(table_name, num, namex, colx, clax, telx):
    conn=pyconn()
    cursor = conn.cursor()
    # cursor.execute(f"UPDATE {table_name} SET password = '{pd}' where user_num = {num}")
    cursor.execute(f"UPDATE {table_name} SET name = '{namex}' where user_num = {num}")
    cursor.execute(f"UPDATE {table_name} SET class = '{clax}' where user_num = {num}")
    cursor.execute(f"UPDATE {table_name} SET telephone = '{telx}' where user_num = {num}")
    cursor.execute(f"UPDATE {table_name} SET college = '{colx}' where user_num = {num}")
    conn.commit()
    cursor.close()
    conn.close()
    return True


def post_pd(table_name, num, pd):
    conn=pyconn()
    cursor = conn.cursor()
    cursor.execute(f"UPDATE {table_name} SET password = '{pd}' where user_num = {num}")
    conn.commit()
    cursor.close()
    conn.close()
    return True


def get_root(table_name, num, name, col, cla, title):
    conn=pyconn()
    cursor = conn.cursor()
    sqlx = f'select * from {table_name} where user_num like "%{num}%" and name like "%{name}%" and college like "%{col}%" and class like "%{cla}%" and title like "%{title}%" order by title desc'
    cursor.execute(sqlx)
    a = cursor.fetchall()
    cursor.close()
    conn.close()
    return a


def post_report(table_name,day, data1, data2, data3):
    conn=pyconn()
    cursor = conn.cursor()
    sqlx = f'delete from {table_name} where day="{day}"'
    cursor.execute(sqlx)
    conn.commit()
    cursor.close()
    conn.close()

    conn = pyconn()
    cursor = conn.cursor()

    data = {
        'day':str(day),
        'time': str(data1),
        'type': str(data2),
        'place': str(data3)
    }
    table = table_name
    keys = ', '.join(data.keys())
    values = ', '.join(['%s'] * len(data))
    sql = 'INSERT INTO {table}({keys}) VALUES ({values})'.format(table=table, keys=keys, values=values)
    cursor.execute(sql, tuple(data.values()))
    conn.commit()
    cursor.close()
    cursor.close()
    return True


def get_report(table_name, data1):
    conn=pyconn()
    cursor = conn.cursor()
    sqlx = f'select * from {table_name} where day like "%{data1}%"'
    cursor.execute(sqlx)
    a = cursor.fetchall()
    cursor.close()
    return a
