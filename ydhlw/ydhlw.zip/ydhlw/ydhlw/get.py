from django.http import HttpResponse
from django.shortcuts import render
import json
from . import getsql

from datetime import date, datetime

class ComplexEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)


# 接收请求数据
def search_get(request):
    ctx = {}
    f = request.GET['q']
    a, b, c = getsql.get_data('user_info', f)
    len_b = len(b)
    bm = []
    for i in range(len_b):
        bm.append(dict(zip(range(len(b[i])), list(b[i]))))
    bx = dict(zip(range(len_b), bm))
    #bx=sorted(bx)
    result = {"result": bx, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

# 接收请求数据
def search_get_any(request):
    ctx = {}
    if request.GET['q1']:
        data1=request.GET['q1']
    else:
        data1='%'
    if request.GET['q2']:
        data2=request.GET['q2']
    else:
        data2='%'
    a, b, c = getsql.get_data_any('student', data1,data2)
    b=sorted(b)
    result = {"result": b, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

# 接收请求数据
def search_get_any_num(request):
    ctx = {}
    if request.GET['q1']:
        data1=request.GET['q1']
    else:
        data1='%'
    if request.GET['q2']:
        data2=request.GET['q2']
    else:
        data2='%'
    num1=request.GET['num1']
    num2 = request.GET['num2']
    a, b, c = getsql.get_data_any_num('student', data1,data2,num1,num2)
    b=sorted(b)
    result = {"result": b, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def load(request):
    message = False
    num = request.GET['num']
    pd = request.GET['pd']
    a, b, c = getsql.get_data_load('user_info', num)
    if a == 0:
        message = '不存在该用户'
        kf=None
    else:
        if str(b[0][1]) == str(pd):
            message = True
            kf=b[0][-1]
        else:
            kf=None
    result = {"result": message, "title": kf, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def get_all(request):
    num = request.GET['num']
    a, b, c= getsql.get_data_all('user_info','user_record',num)
    b=sorted(b)
    result = {"result":b,"msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False,cls=ComplexEncoder), content_type="application/json,charset=utf-8")

def get_no(request):
    if request.GET['data1']:
        data1 = request.GET['data1']
    else:
        data1 = '%'

    if request.GET['data2']:
        data2 = request.GET['data2']
    else:
        data2 = '%'

    if request.GET['data3']:
        data3 = request.GET['data3']
    else:
        data3 = '%'

    a, b = getsql.get_list('user_info', 'user_record', data1, data2, data3)
    a=sorted(a)
    result = {"result": a,"msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def get_yes(request):
    if request.GET['data1']:
        data1 = request.GET['data1']
    else:
        data1 = '%'

    if request.GET['data2']:
        data2 = request.GET['data2']
    else:
        data2 = '%'

    if request.GET['data3']:
        data3 = request.GET['data3']
    else:
        data3 = '%'

    a, b = getsql.get_yes('user_info', 'user_record', data1, data2, data3)
    a=sorted(a)
    result = {"result": a, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False,cls=ComplexEncoder), content_type="application/json,charset=utf-8")

def get_del(request):
    num = request.GET['num']
    a= getsql.get_del('user_info','user_record' ,num)
    a=sorted(a)
    result = {"result": a, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def get_root(request):
    num = request.GET['num']
    name= request.GET['name']
    col = request.GET['col']
    cla = request.GET['cla']
    title = request.GET['title']
    a= getsql.get_root('user_info', num,name,col,cla,title)
    a=sorted(a)
    result = {"result": a, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def get_report(request):
    day = request.GET['day']
    a= getsql.get_report('user_report', day)
    result = {"result": a, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")