from django.shortcuts import render
from django.views.decorators import csrf
from django.http import HttpResponse
import json
import datetime
import pytz
from . import getsql

# 接收POST请求数据

def getTime():
    now = datetime.datetime.now(pytz.timezone('Asia/Shanghai')).replace(microsecond=0).strftime('%Y-%m-%d  %H:%M:%S')
    return now,True

def search_post(request):
    try:
        data1 = request.GET['data1']
        data2 = request.GET['data2']
    except:
        data1 = request.POST['data1']
        data2 = request.POST['data2']
    zt=getsql.post_data('student',data1,data2)
    result = {"result":zt, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def sign(request):
    try:
        num = request.GET['num']
        pd = request.GET['pd']
        name = request.GET['name']
        classx = request.GET['cla']
        tel = request.GET['tel']
        col = request.GET['col']
    except:
        num = request.POST['num']
        pd = request.POST['pd']
        name = request.POST['name']
        classx = request.POST['cla']
        tel = request.POST['tel']
        col = request.POST['col']
    zt=getsql.post_sign('user_info',num,pd,name,classx,tel,col)
    result = {"result":zt, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def change_title(request):
    try:
        num = request.GET['num']
        title=request.GET['title']
    except:
        num = request.POST['num']
        title = request.POST['title']
    zt = getsql.post_title('user_info', num,title)
    result = {"result": zt, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def post_record(request):
    now,msg=getTime()
    try:
        num = request.GET['num']
        title=request.GET['title']
    except:
        num = request.POST['num']
        title = request.POST['title']
    zt = getsql.post_record('user_record', num,title,now)
    result = {"result": zt, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def post_me(request):
    try:
        num = request.GET['num']
        
        name=request.GET['name']
        col = request.GET['col']
        cla = request.GET['cla']
        tel = request.GET['tel']
    except:
        num = request.POST['num']
        
        name = request.POST['name']
        col = request.POST['col']
        cla = request.POST['cla']
        tel = request.POST['tel']
    zt = getsql.post_me('user_info', num,name,col,cla,tel)
    result = {"result": zt, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def post_pd(request):
    try:
        num = request.GET['num']
        pd1 = request.GET['pd1']
        pd2 = request.GET['pd2']

    except:
        num = request.POST['num']
        pd1 = request.POST['pd1']
        pd2 = request.POST['pd2']
    message=False
    a, b, c = getsql.get_data_load('user_info', num)
    if a == 0:
        message = '不存在该用户'
    else:
        if str(b[0][1]) == str(pd1):
            message = True
    if message:
        zt = getsql.post_pd('user_info', num,pd2)
    result = {"result": message, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")

def post_report(request):
    try:
        day = request.GET['day']
        time = request.GET['time']
        type = request.GET['type']
        place = request.GET['place']

    except:
        day = request.POST['day']
        time = request.POST['time']
        type = request.POST['type']
        place = request.POST['place']
    message=False
    message = getsql.post_report('user_report', day,time,type,place)

    result = {"result": message, "msg": "执行成功"}
    # json返回为中文
    return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")
