from django.http import HttpResponse
from django.shortcuts import render

def ping(request):
    return HttpResponse("124.222.37.80服务器状态正常")

def index(request):
    context={}
    return render(request, 'index.html', context)